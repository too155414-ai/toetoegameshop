import 'dotenv/config';
const base=(process.env.MGC_BASE_URL||'https://api.mgamecoin.com/api/v1/seller').replace(/\\/$/,'');
async function call(path,options={}){if(!process.env.MGC_API_KEY)throw new Error('MGC_API_KEY is not configured');const r=await fetch(base+path,{...options,headers:{Accept:'application/json','Content-Type':'application/json','X-API-Key':process.env.MGC_API_KEY,...options.headers}});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.message||`MGC error ${r.status}`);return d}
export const listProducts=slug=>call(`/games/${encodeURIComponent(slug)}/products`);
export const checkPlayerId=payload=>call('/id-check',{method:'POST',body:JSON.stringify(payload)});
export async function createSupplierOrder(payload,key){if(process.env.MGC_ENABLE_ORDERS!=='true')throw new Error('Supplier orders are disabled until official schema and sandbox tests are complete');if(!key)throw new Error('Idempotency key required');return call('/orders',{method:'POST',headers:{'X-Idempotency-Key':key},body:JSON.stringify(payload)})}
