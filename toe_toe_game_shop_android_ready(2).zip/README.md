# Toe Toe Game Shop (Starter)

မြန်မာဘာသာ Customer Website + Admin API starter.

## ပါဝင်မှု
- PUBG Mobile UC / Mobile Legends Diamonds UI
- Player ID / Server ID form
- KBZPay / WavePay payment method selection
- WavePay QR display (assets/wavepay-qr.png)
- Order reference submission UI
- Express API demo endpoints and MGC adapter placeholder

## လုပ်ဆောင်ရန်
1. Node.js 20+ တပ်ဆင်ပါ။
2. `cd server && npm install`
3. `cp .env.example .env` ပြီး API keys/token ကို သင့်စက်ထဲတွင်သာ ဖြည့်ပါ။
4. `npm run dev`
5. နောက် Terminal တစ်ခုတွင် `cd client && npm install && npm run dev`

Customer site: http://localhost:5173
API: http://localhost:8080

## အရေးကြီး
- ဤသည် စတင်အသုံးပြုရန် Demo/Starter ဖြစ်ပြီး Production-ready မဟုတ်သေးပါ။
- Orders/payment records များသည် memory ထဲတွင်သာ သိမ်းသည်။ Server restart လုပ်လျှင် ပျောက်နိုင်သည်။
- WavePay QR သည် ငွေလက်ခံရန် QR ကိုသာ ပြသည်။ Screenshot သို့မဟုတ် reference တင်ခြင်းက ငွေဝင်ကြောင်း အလိုအလျောက်မစစ်နိုင်ပါ။
- ငွေလက်ခံမှုကို Merchant App/Portal တွင် ကိုယ်တိုင်စစ်ပြီး Admin က အတည်ပြုပြီးမှ supplier top-up လုပ်ပါ။
- KBZPay ကိုလည်း Merchant QR/reference နည်းလမ်းအဖြစ် placeholder ထားထားသည်။
- MGC order submit ကို default ပိတ်ထားသည်။ Official docs + sandbox key + successful tests မရမချင်း မဖွင့်ပါနှင့်။
- API key, admin token, wallet PIN/OTP/password များကို chat ထဲမပို့ပါနှင့်။


## Android APK ပြုလုပ်ရန် (ကိုယ်ပိုင် Computer လိုအပ်သည်)
ဤ project သည် Android APK မဟုတ်သေးပါ။ Android Studio + Android SDK + JDK လိုအပ်သည်။

1. Android Studio ကို install လုပ်ပြီး Android SDK ကို setup လုပ်ပါ။
2. `cd client`
3. `npm install`
4. `npx cap add android` (ပထမဆုံးတစ်ကြိမ်သာ)
5. `npm run build:android`
6. `npx cap open android` ဖြင့် Android Studio ဖွင့်ပါ။
7. Android Studio တွင် Build > Build Bundle(s) / APK(s) > Build APK(s) ကိုရွေးပါ။

မှတ်ချက်: App ကို အများသုံးမတင်မီ API server ကို HTTPS public hosting တွင် deploy လုပ်ပြီး
`VITE_API_URL` ကို production API URL သို့ ပြောင်း၍ ပြန် build လုပ်ပါ။
လက်ရှိ `localhost` API URL သည် အခြားဖုန်းများမှ အသုံးပြုနိုင်သော public server မဟုတ်ပါ။
